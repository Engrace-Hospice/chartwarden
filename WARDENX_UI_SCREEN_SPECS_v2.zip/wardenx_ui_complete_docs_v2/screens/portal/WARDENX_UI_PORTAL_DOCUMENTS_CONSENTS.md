# WARDENX_UI_PORTAL_DOCUMENTS_CONSENTS

Version: 1.0  
Status: Screen Specification  
Module: Portal Documents / Consents

---

## Purpose

Allows patients/families to view, acknowledge, and sign documents where permitted.

---

## Layout

```text
Document List
Document Viewer
Action Panel
```

---

## Document Categories

- Patient rights
- Privacy notice
- Consent forms
- Plan of care summary
- Visit summaries if enabled
- Education materials

---

## Actions

- View
- Download
- Acknowledge
- Sign
- Ask question
