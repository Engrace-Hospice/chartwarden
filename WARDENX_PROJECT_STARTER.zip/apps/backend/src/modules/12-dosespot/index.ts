// apps/backend/src/modules/12-dosespot — Phase 0 placeholder owned per module-manifest.ts. No business logic yet.
export {};
