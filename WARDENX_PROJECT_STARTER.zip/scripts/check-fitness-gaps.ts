/**
 * WardenX — Fitness Gap Checks (event catalog · seam registry · PHI guards)
 * -------------------------------------------------------------------------
 * Closes the three enforcement gaps the fitness audit flagged as runtime-only
 * (FITNESS_EVENT_SEAM_CATALOG.md §C). Each sub-check is GROUNDED in the manifest +
 * the ratified conventions and is ARMED-BUT-INERT until the relevant implementation
 * source lands — the same posture as check-table-ownership.ts / check-tenancy.ts
 * (heuristic, import-level, "activates per file as source lands"). With no
 * apps//packages/ code yet, all three report `inert` and exit 0; once code lands they
 * begin enforcing automatically.
 *
 *   1. EVENT CATALOG  — every outbox event name follows `mN.<resource>.<verb>` and the
 *      declaring module owns the `mN.` prefix (ADR/M01 D8 outbox_event_catalog; M03 D9;
 *      M04 action-catalog convention). Declared `consumers` must be real module ids.
 *      Source: outbox-events registry / events-by-mN.ts contribution files.
 *   2. SEAM REGISTRY  — every seam consumed (boot-injected) is registered in REQUIRED_SEAMS
 *      and exposed by some module (validateSeams() completeness, statically).
 *      Source: seams directories, REQUIRED_SEAMS, registerSeam(...).
 *   3. PHI GUARDS     — every PHI table (org-scoped) declares an RLS policy + an audit
 *      trigger (M01 RLS generator + M04 audit triggers).
 *      Source: packages/db schema files + migration .sql files.
 *
 * Run: bun run scripts/check-fitness-gaps.ts   (alias: bun run arch:gaps)
 * CI:  exits 1 on any violation; exits 0 (with an `inert` note) when source is absent.
 */
import { readdirSync, readFileSync, statSync, existsSync } from "node:fs";
import { join } from "node:path";
import { MODULES } from "../architecture/module-manifest";

const ROOT = process.cwd();
const moduleIds = new Set((MODULES as { id: number }[]).map((m) => m.id));
const M = (n: number) => `M${String(n).padStart(2, "0")}`;

// Unprefixed system events are explicitly permitted by M01 D8 ("or it's an unprefixed
// system event"). Keep this allowlist tight and visible.
const SYSTEM_EVENT_ALLOWLIST = new Set<string>([
  // none ratified yet — add deliberately, with an ADR reference
]);

type V = { check: string; detail: string };
const violations: V[] = [];
const notes: string[] = [];
const fail = (check: string, detail: string) => violations.push({ check, detail });

function walk(dir: string, test: RegExp, acc: string[] = []): string[] {
  let entries: string[] = [];
  try { entries = readdirSync(join(ROOT, dir)); } catch { return acc; }
  for (const e of entries) {
    const rel = join(dir, e);
    let st; try { st = statSync(join(ROOT, rel)); } catch { continue; }
    if (st.isDirectory()) {
      if (["node_modules", ".git", "dist", ".turbo"].includes(e)) continue;
      walk(rel, test, acc);
    } else if (test.test(rel)) acc.push(rel);
  }
  return acc;
}
const hasAppSource = existsSync(join(ROOT, "apps")) || existsSync(join(ROOT, "packages"));

// ---- 1. EVENT CATALOG -------------------------------------------------------
{
  const files = [
    ...walk("packages", /(outbox-events|events-by-m\d+)\.ts$|outbox-events\/.+\.ts$/),
    ...walk("apps", /(outbox-events|events-by-m\d+)\.ts$|outbox-events\/.+\.ts$/),
  ];
  if (files.length === 0) {
    notes.push("event-catalog: inert (no outbox-event registry source yet) — armed");
  } else {
    for (const f of files) {
      const src = readFileSync(join(ROOT, f), "utf8");
      // event name string literals: eventName: '...' | publish('...') | name: "mN..."
      const names = new Set<string>();
      for (const m of src.matchAll(/\b(?:eventName|name)\s*:\s*['"]([a-z0-9_]+\.[a-z0-9_.]+)['"]/g)) names.add(m[1]!);
      for (const m of src.matchAll(/\bpublish\(\s*['"]([a-z0-9_]+\.[a-z0-9_.]+)['"]/g)) names.add(m[1]!);
      const fileModule = /events-by-m(\d+)\.ts$/.exec(f)?.[1];
      for (const name of names) {
        if (SYSTEM_EVENT_ALLOWLIST.has(name)) continue;
        const mPrefix = /^m(\d+)\./.exec(name);
        if (!mPrefix) {
          fail("event-naming", `'${name}' (${f}) does not follow the mN.<resource>.<verb> convention (M01 D8 / M03 D9)`);
          continue;
        }
        const owner = Number(mPrefix[1]);
        if (!moduleIds.has(owner)) fail("event-owner", `'${name}' uses prefix m${owner} which is not a module id`);
        if (fileModule && Number(fileModule) !== owner)
          fail("event-namespace", `${f} (module m${fileModule}) declares '${name}' under another module's m${owner} prefix`);
      }
      // declared consumers must be real modules
      for (const m of src.matchAll(/consumers\s*:\s*\[([^\]]*)\]/g)) {
        for (const c of m[1]!.matchAll(/['"]m(\d+)['"]/g)) {
          const cid = Number(c[1]);
          if (!moduleIds.has(cid)) fail("event-consumer", `${f} declares consumer m${cid} which is not a module id`);
        }
      }
    }
    notes.push(`event-catalog: scanned ${files.length} registry file(s)`);
  }
}

// ---- 2. SEAM REGISTRY -------------------------------------------------------
{
  const seamFiles = [...walk("packages", /seams?\/.+\.ts$|REQUIRED_SEAMS/), ...walk("apps", /seams?\/.+\.ts$/)];
  const registryHit = seamFiles.some((f) => /REQUIRED_SEAMS|registerSeam/.test(readFileSync(join(ROOT, f), "utf8")));
  if (seamFiles.length === 0 || !registryHit) {
    notes.push("seam-registry: inert (no seam registry source yet) — armed");
  } else {
    const registered = new Set<string>();
    const consumed = new Map<string, string>();
    for (const f of seamFiles) {
      const src = readFileSync(join(ROOT, f), "utf8");
      for (const m of src.matchAll(/registerSeam\(\s*['"]([A-Za-z0-9_]+)['"]/g)) registered.add(m[1]!);
      for (const m of src.matchAll(/REQUIRED_SEAMS\s*=\s*\[([^\]]*)\]/g))
        for (const s of m[1]!.matchAll(/['"]([A-Za-z0-9_]+)['"]/g)) registered.add(s[1]!);
      for (const m of src.matchAll(/getSeam\(\s*['"]([A-Za-z0-9_]+)['"]/g)) consumed.set(m[1]!, f);
    }
    for (const [seam, f] of consumed)
      if (!registered.has(seam)) fail("seam-unregistered", `seam '${seam}' is consumed in ${f} but not in REQUIRED_SEAMS / registerSeam`);
    notes.push(`seam-registry: ${registered.size} registered, ${consumed.size} consumed`);
  }
}

// ---- 3. PHI GUARDS (RLS + audit trigger presence) ---------------------------
{
  const schemaFiles = [...walk("packages", /schema.*\.ts$/), ...walk("packages", /\.sql$/), ...walk("apps", /\.sql$/)];
  if (schemaFiles.length === 0) {
    notes.push("phi-guards: inert (no schema/migration source yet) — armed");
  } else {
    // Heuristic: a table whose definition references organization_id is PHI/org-scoped and
    // must have both an RLS policy and an audit trigger somewhere in the schema corpus.
    const corpus = schemaFiles.map((f) => readFileSync(join(ROOT, f), "utf8")).join("\n");
    const orgScoped = new Set<string>();
    for (const m of corpus.matchAll(/create table\s+(?:if not exists\s+)?["']?(\w+)["']?[\s\S]{0,4000}?organization_id/gi)) orgScoped.add(m[1]!);
    for (const t of orgScoped) {
      if (!new RegExp(`enable row level security[\\s\\S]*?${t}|${t}[\\s\\S]*?enable row level security|policy[\\s\\S]*?on\\s+${t}\\b`, "i").test(corpus))
        fail("rls-missing", `org-scoped table '${t}' has no RLS policy/enable (M01 RLS generator)`);
      if (!new RegExp(`trigger[\\s\\S]*?on\\s+${t}\\b[\\s\\S]*?(audit|wardenx_audit)`, "i").test(corpus))
        fail("audit-trigger-missing", `org-scoped table '${t}' has no audit trigger (M04)`);
    }
    notes.push(`phi-guards: scanned ${schemaFiles.length} schema file(s), ${orgScoped.size} org-scoped table(s)`);
  }
}

// ---- report -----------------------------------------------------------------
const armed = !hasAppSource ? " [no app source — all checks armed/inert]" : "";
if (violations.length === 0) {
  console.log(`✓ fitness-gaps: ${notes.join(" · ")}${armed}`);
  process.exit(0);
}
console.error(`✗ fitness-gaps: ${violations.length} violation(s)\n  ${notes.join(" · ")}\n`);
for (const v of violations) console.error(`  [${v.check}] ${v.detail}`);
process.exit(1);
