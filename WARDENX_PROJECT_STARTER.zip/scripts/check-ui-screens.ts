/**
 * WardenX — UI Screen-Spec Corpus Consistency Check
 * -------------------------------------------------
 * Keeps the docs/ui/ corpus internally coherent. Catches the drift that is easy
 * to introduce when adding screens by hand:
 *
 *   1. INDEX PARITY — every screen file under docs/ui/screens/ is listed in
 *      WARDENX_UI_COMPLETE_SCREEN_INDEX.md, and every index entry points to a file
 *      that exists (no orphans, no stragglers, no duplicates).
 *   2. LAYOUT-HEADING HYGIENE — every screen declares its layout via
 *      `## Layout Pattern` + a single `Use <name>.` line (no bare `## Layout`,
 *      no missing declaration).
 *   3. PATTERN RESOLUTION — every pattern token in a `Use A + B.` declaration
 *      resolves to a pattern defined in WARDENX_UI_LAYOUT_PATTERNS.md (a `### Name`
 *      base/foundational heading, or a Tier-3 modifier table row).
 *
 * Authoritative-by-construction: the glossary is the source of truth for pattern
 * names; the index is the source of truth for the screen set. This check asserts
 * the specs agree with both.
 *
 * Run:   bun run scripts/check-ui-screens.ts   (alias: bun run docs:ui)
 * CI:    exits 1 on any violation.
 */

import { readdirSync, readFileSync, existsSync, statSync } from "node:fs";
import { join, relative } from "node:path";

const REPO_ROOT = process.cwd();
const UI_DIR = "docs/ui";
const SCREENS_DIR = join(UI_DIR, "screens");
const INDEX_FILE = join(UI_DIR, "WARDENX_UI_COMPLETE_SCREEN_INDEX.md");
const GLOSSARY_FILE = join(UI_DIR, "WARDENX_UI_LAYOUT_PATTERNS.md");

type Violation = { check: string; detail: string };
const violations: Violation[] = [];
const fail = (check: string, detail: string) => violations.push({ check, detail });

function read(rel: string): string {
  return readFileSync(join(REPO_ROOT, rel), "utf8");
}

function listScreens(dir: string, acc: string[] = []): string[] {
  for (const e of readdirSync(join(REPO_ROOT, dir))) {
    const rel = join(dir, e);
    if (statSync(join(REPO_ROOT, rel)).isDirectory()) listScreens(rel, acc);
    else if (/^WARDENX_UI_.+\.md$/.test(e)) acc.push(rel);
  }
  return acc;
}

// ---- gather the screen set (relative to docs/ui/, matching index entries) ----
const screenFiles = listScreens(SCREENS_DIR)
  .map((p) => relative(UI_DIR, p))
  .sort();

// ---- 1. INDEX PARITY ----
const indexSrc = read(INDEX_FILE);
const indexEntries = [...indexSrc.matchAll(/`(screens\/[^`]+\.md)`/g)].map((m) => m[1]!);
const indexSet = new Set<string>();
for (const e of indexEntries) {
  if (indexSet.has(e)) fail("index-duplicate", `'${e}' is listed more than once in the index`);
  indexSet.add(e);
}
for (const f of screenFiles)
  if (!indexSet.has(f)) fail("index-missing", `${f} exists but is not listed in the screen index`);
for (const e of indexEntries)
  if (!existsSync(join(REPO_ROOT, UI_DIR, e))) fail("index-orphan", `index lists '${e}' but no such file exists`);

// ---- build the set of patterns DEFINED in the glossary ----
const glossarySrc = read(GLOSSARY_FILE);
const defined = new Set<string>();
// base / foundational patterns: "### Name **[named in specs]**" / "### Name **[proposed]**"
for (const m of glossarySrc.matchAll(/^###\s+(.+?)\s+\*\*\[/gm)) defined.add(m[1]!.trim());
// modifiers: bold tokens inside the Tier-3 modifier table
const tier3 = glossarySrc.slice(glossarySrc.indexOf("## Tier 3 — Modifiers"));
const tier3Body = tier3.slice(0, tier3.indexOf("\n## ", 1) >= 0 ? tier3.indexOf("\n## ", 1) : undefined);
for (const line of tier3Body.split("\n")) {
  if (!line.startsWith("| **")) continue;
  for (const m of line.matchAll(/\*\*([^*]+)\*\*/g)) defined.add(m[1]!.trim());
}

// ---- 2 & 3. per-screen: layout heading hygiene + pattern resolution ----
for (const f of screenFiles) {
  const src = read(join(UI_DIR, f));
  if (/^## Layout$/m.test(src))
    fail("bare-layout-heading", `${f} uses bare '## Layout' — must be '## Layout Pattern'`);

  const useLines = [...src.matchAll(/^Use (.+?)\.\s*$/gm)];
  if (useLines.length === 0) {
    fail("no-pattern", `${f} declares no layout pattern (expected a 'Use <name>.' line)`);
    continue;
  }
  if (useLines.length > 1)
    fail("multi-pattern", `${f} declares ${useLines.length} 'Use ...' lines — expected exactly one`);

  for (const token of useLines[0]![1]!.split("+").map((s) => s.trim())) {
    if (!defined.has(token))
      fail("undefined-pattern", `${f} references layout pattern '${token}', not defined in the glossary`);
  }
}

// ---- report ----
const checked = `${screenFiles.length} screens · ${defined.size} patterns · ${indexEntries.length} index entries`;
if (violations.length === 0) {
  console.log(`✓ ui-screens: corpus consistent (${checked})`);
  process.exit(0);
}
console.error(`✗ ui-screens: ${violations.length} issue(s)  [${checked}]\n`);
for (const v of violations) console.error(`  [${v.check}] ${v.detail}`);
process.exit(1);
